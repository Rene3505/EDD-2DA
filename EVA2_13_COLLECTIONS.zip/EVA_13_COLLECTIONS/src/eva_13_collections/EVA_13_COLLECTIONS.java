
package eva_13_collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;


public class EVA_13_COLLECTIONS {


    public static void main(String[] args) {
        //OPERA COMO UNA LISTA DOBLE
        LinkedList<Integer> lista = new LinkedList<Integer>();
        lista.add(100);
        lista.add(200);
        lista.add(300);
        lista.add(400);  
        lista.add(500);
        System.out.println("Tamaño: "+lista.size());
        System.out.println(lista);
        lista.clear();
        System.out.println("Tamaño: "+lista.size());
        System.out.println(lista);
        
        //ARRAYLIST
        //TRABAJA CON ARREGLOS
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("Mundo");
        arrayList.add("!!!");
        System.out.println(arrayList);
        System.out.println(arrayList.size());
        
        //QUEUE
        Queue<Integer> queue = new PriorityQueue<>();
        queue.add(100);
        queue.add(100);
        queue.add(100);
        queue.add(100);
        queue.add(100);
        System.out.println(queue.peek());
        System.out.println(queue.poll());
        System.out.println(queue.peek());
        System.out.println(queue);
        
        
        
    }
    
}
