package eva2_12_arbol_binario;

public class Nodo {
    
    //DOS ATRIBUTOS
    private int valor;
    private Nodo derecha;
    private Nodo izquierda;
    
    //CONSTRUCTORES
    public Nodo() {
        this.derecha = null; //MUY IMPORTANTE, MARCA EL FIN DE LA LISTA
        this.izquierda = null;
    }
    
    public Nodo(int valor) { //PONER EL VALOR A GUARDAR, AL MOMENTO DE CREAR EL NODO
        this.valor = valor;
        this.derecha = null;
        this.izquierda = null;
    }
    
    //get y set
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
    
    public Nodo getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }    
}