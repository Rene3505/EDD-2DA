
package eva2_12_arbol_binario;


public class ArbolBinario {
    private Nodo root;

    public ArbolBinario() {
        root = null;
    }
    
    public void agregar(int valor){
        //ESTA VACIO EL ARBOL
        if(root == null){//arbol vacio
            root = new Nodo(valor); //inserto el valor
        } else { 
            agregarRecu(root,valor);
        }
    }
    //METODO RECURSIVO
   private void agregarRecu(Nodo actual, int valor){
       if(valor > actual.getValor()){//A LA DERECHA
           if(actual.getDerecha() != null){//OCUPADO
           agregarRecu(actual.getDerecha(), valor);
           } else {//DISPONIBLE
               actual.setDerecha(new Nodo(valor));
           }
       } else if(valor < actual.getValor()) { //A LA IZQUIERDA
           if(actual.getIzquierda() != null){//OCUPADO
           agregarRecu(actual.getIzquierda(), valor);
           } else {//DISPONIBLE
               actual.setIzquierda(new Nodo(valor));
           }       
       } /*ELSE ---> EL VALOR ESTA REPETIDO*/
   }
   
   public void preOrder(){
       System.out.println("");
       preOrderRecu(root);
   }
   
   private void preOrderRecu(Nodo actual){
   if (actual != null){
       System.out.print(actual.getValor()+" - ");
   preOrderRecu(actual.getIzquierda());//LEE EL LADO IZQUIERDO
   preOrderRecu(actual.getDerecha());//LEE LADO DERECHO
    }
   }

   public void postOrder(){
       System.out.println("");
       postOrderRecu(root);
   }
   
   private void postOrderRecu(Nodo actual){
   if (actual != null){
   postOrderRecu(actual.getIzquierda());//LEE EL LADO IZQUIERDO
   postOrderRecu(actual.getDerecha());//LEE LADO DERECHO
       System.out.print(actual.getValor()+" - ");    
    }
   }

   public void inOrder(){
       System.out.println("");
       inOrderRecu(root);
   }
   
   private void inOrderRecu(Nodo actual){
   if (actual != null){
   inOrderRecu(actual.getIzquierda());//LEE EL LADO IZQUIERDO
   System.out.print(actual.getValor()+" - ");   
   inOrderRecu(actual.getDerecha());//LEE LADO DERECHO    
    }
   }
}

