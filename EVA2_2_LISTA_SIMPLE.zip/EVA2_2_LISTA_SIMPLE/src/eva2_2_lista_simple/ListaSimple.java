package eva2_2_lista_simple;

public class ListaSimple {
    private Nodo inicio;
    private Nodo fin;
    private int tam;
    
    public ListaSimple(){
        inicio = null; //la lista se crea vacía
        fin = null;
        tam = 0;
    }
    
    //SIEMPRE SE AGREGA AL FINAL DE LA LISTA
    //O(N) -> SE AGREGA AL FINAL, SE RECORREN TODOS
    public void agregar(int valor){
        Nodo nuevo = new Nodo(valor); //creo el nodo para el valor a insertar
        if(inicio == null){ //Lista vacía? verdadero
            inicio = nuevo; //nuevo es el primer nodo de la lista
            fin = nuevo;
        }else{ //lista con nodos
            //movernos al final
            //Nodo temp = inicio;
            //while(temp.getSiguiente() != null){
              //  temp = temp.getSiguiente();
            
            //temp.setSiguiente(nuevo); //conecto nuevo al final de la lista
            fin.setSiguiente(nuevo);
            fin = nuevo;           
        }
        tam++; 
     }
     //O(N)
    
    public void imprimir(){
        System.out.println("");
        Nodo temp = inicio;
        while(temp != null){
            System.out.print("[" + temp.getValor() + "]");
            temp = temp.getSiguiente();
        }
    }
    
    //O(1)
    public int longitud(){
        return tam;
    }
    
    //O(1)
    public boolean listaVacia(){
        if(inicio == null){ //LISTA VACÍA = VERDADERO
            return true;
        }else{//LISTA CON NODOS
            return false;
        }
    }
    
    //O(N)
    public void vaciarLista(){
        inicio = null;
        fin = null;
        tam = 0;
    }
    //O(N)
    public int encontrar(int valor){
        int posi = 0;
        Nodo temp = inicio;
        
        while(temp != null){
            if(valor == temp.getValor()){
            return posi;
            } 
            temp = temp.getSiguiente();
            posi++;
        }
        return -1;
    }
    
    public int valorEn(int posi){
        int tama = longitud();
        if (posi< 0 || posi >= tam){return 0;}else{
        int valor = 0;
        Nodo temp = inicio;  
        
        for (int i = 0; i < posi; i++) {
            temp = temp.getSiguiente();
        }
        return temp.getValor();  
        }
    }
    
    //O(N) 
    public ListaSimple respaldar() {
        ListaSimple listaRespaldo = new ListaSimple();
        Nodo temp = inicio;
    
        while (temp != null) {
            listaRespaldo.agregar(temp.getValor()); 
            temp = temp.getSiguiente();
        }
        return listaRespaldo;
    }

    public void InsertarEn(int valor, int posi){
    int tama = longitud();
    if(posi< 0 || posi >= tam){
        return;
    }
            if (posi == 0){
         Nodo nuevo = new Nodo(valor);
         if (listaVacia()){
             inicio = nuevo;
             fin = nuevo;
            } else {
             nuevo.setSiguiente(inicio);
             inicio = nuevo;
            }
         tam++;
         return;
         }
            
            if (posi == tama){
                agregar(valor);
                return;
            }
        
        Nodo nuevo = new Nodo(valor);
        Nodo temp = inicio;
        
         for (int i = 0; i < posi-1; i++) {
            temp = temp.getSiguiente();
        }
        
         nuevo.setSiguiente(temp.getSiguiente());
         temp.setSiguiente(nuevo);
         tam++;
    }

    //O(N)
    public void BorrarEn(int posi){
        
    int tama = longitud();
    if(posi< 0 || posi >= tam){
        return;
    }
    
    if(posi == 0){
        inicio = inicio.getSiguiente();
        if (inicio == null){
            fin = null;
            }
        tam--;
        return;
        }
    
    Nodo temp = inicio;
        for (int i = 0; i < posi - 1; i++) {
            temp = temp.getSiguiente();
        }
        Nodo borrar = temp.getSiguiente();
        temp.setSiguiente(borrar.getSiguiente());
        if(borrar==fin){
        fin = temp;
        }
        tam--;
    }
 
    //IMPRIMIR INVERSAMENTE RECORRIENDO TODOS LOS NODOS
    //O(N)
    public void imprimirInv(){
        int tama = longitud();
        System.out.println("");
        Nodo temp = inicio;
        int[] valores = new int[tama];
        for (int i = 0; i < tama; i++) {
            valores[i] = temp.getValor();
            temp = temp.getSiguiente();
        }
        for (int i = tama-1; i >= 0; i--) {
            System.out.print("[" + valores[i] +"]");
        }
    }    
}