package eva2_2_lista_simple;

public class Nodo {
    
    //DOS ATRIBUTOS
    private int valor;
    private Nodo siguiente;
    
    //CONSTRUCTORES
    public Nodo() {
        siguiente = null; //MUY IMPORTANTE, MARCA EL FIN DE LA LISTA
    }
    
    public Nodo(int valor) { //PONER EL VALOR A GUARDAR, AL MOMENTO DE CREAR EL NODO
        this.valor = valor;
        siguiente = null;
    }
    
    //get y set
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}