
package eva2_3_lista_doble;


public class EVA2_3_LISTA_DOBLE {


    public static void main(String[] args) {
        ListaDoble lista = new ListaDoble();
        lista.agregar(100);
        lista.agregar(200);
        lista.agregar(300);
        lista.agregar(400);
        lista.agregar(500);
        lista.imprimir();
        lista.imprimirInv();
        lista.imprimir();
        lista.agregar(600);
        lista.agregar(700);
        lista.agregar(800); 
        lista.agregar(900); 
        lista.agregar(1000); 
        lista.InsertarEn(1000, 3);
        lista.InsertarEn(999, 7);
        lista.InsertarEn(250, 10);
        lista.InsertarEn(0, 1);
        lista.imprimir();
        lista.imprimirInv();
        lista.BorrarEn(4);
        lista.BorrarEn(7);
        lista.imprimir();
        lista.imprimirInv();
    }
    
}
