package eva2_3_lista_doble;

public class Nodo {
    
    //DOS ATRIBUTOS
    private int valor;
    private Nodo siguiente;
    private Nodo previo;
    
    //CONSTRUCTORES
    public Nodo() {
        this.siguiente = null; //MUY IMPORTANTE, MARCA EL FIN DE LA LISTA
        this.previo = null;
    }
    
    public Nodo(int valor) { //PONER EL VALOR A GUARDAR, AL MOMENTO DE CREAR EL NODO
        this.valor = valor;
        this.siguiente = null;
        this.previo = null;
    }
    
    //get y set
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
    
    public Nodo getPrevio() {
        return previo;
    }

    public void setPrevio(Nodo previo) {
        this.previo = previo;
    }    
}