
package eva2_6_tipos_genericos;


public class EVA2_6_TIPOS_GENERICOS {


    public static void main(String[] args) {
        //int --> Integer, double --> Double
        Ejemplo<ListaDoble> prueba = new Ejemplo<ListaDoble>{};
        //prueba.
                
    }
    
}

class ListaDoble{}

class Ejemplo<T>{
    private T dato;

    public Ejemplo(T dato) {
        this.dato = dato;
    }
    
    public Ejemplo() {
    }
     public T getDato(){
         return dato;
     }

    public void setDato(T dato) {
        this.dato = dato;
    }
     
}
