
package eva2_9_factorial;


public class EVA2_9_FACTORIAL {

    public static void main(String[] args) {
        System.out.println("Factorial de 5 = "+ factorialNumero(5));
        System.out.println("Factorial de 5 = "+ factorialRecu(5));        
    }
    
    public static int factorialNumero(int valor){
    int resu = 1;
        for (int i = 1; i <= valor; i++) {
            resu = resu*i;
        }
    return resu;
        
    }
    
    public static int factorialRecu(int valor){
        if(valor == 0)
            return 1;
        else
        return valor * factorialRecu(valor - 1);
    }
    
}
