package eva2_11_fibonacci;


public class EVA2_11_FIBONACCI {


   public static void main(String[] args) {
      System.out.println("3= "+fibonacciRecu(3));
   }
   
   
   public static int fibonacciRecu(int posi){
   if (posi > 0) 
      return fibonacciRecu(posi - 1) + fibonacciRecu(posi - 2);
     else
     return 1;
   }
   
}
