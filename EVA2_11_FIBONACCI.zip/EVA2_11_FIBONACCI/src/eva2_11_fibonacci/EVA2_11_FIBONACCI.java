package eva2_11_fibonacci;


public class EVA2_11_FIBONACCI {


   public static void main(String[] args) {
      System.out.println(+fibonacciRecu(5));
   }
   
   public static int fibonacciRecu(int posi){
   if (posi == 1 || posi == 0) 
      return posi;
     else
     return fibonacciRecu(posi - 1) + fibonacciRecu(posi - 2);
   }
   
}
