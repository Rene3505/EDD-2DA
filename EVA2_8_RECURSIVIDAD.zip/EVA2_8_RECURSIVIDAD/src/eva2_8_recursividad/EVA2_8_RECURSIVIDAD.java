
package eva2_8_recursividad;


public class EVA2_8_RECURSIVIDAD {

    public static void main(String[] args) {
        imprimirCiclo(5);
        imprimirRecu(5);
    }
    
    public static void imprimirCiclo(int num){
        for (int i = num; i >- 0; i--) {
            System.out.print(i+ " - ");
        }
        System.out.println("");
    }
    public static void imprimirRecu(int num){
        //RESUELVA UNA PARTE DEL PROBLEMA
        System.out.print(num +" - ");
        //SE LLAME A SI MISMO
        if(num > 1)//DETENER LA RECURSIVIDAD
        imprimirRecu(num-1);
    }
    
}
