package eva2_4_queue;
public class MyQueue {
    private Nodo inicio;
    private Nodo fin;
    private int tam;
        
    public MyQueue(){
        inicio = null; //la lista se crea vacía
        fin = null;
        tam = 0;
    }
    
    public void imprimir(){
        System.out.println("");
        Nodo temp = inicio;
        while(temp != null){
            System.out.print("[" + temp.getValor() + "]");
            temp = temp.getSiguiente();
        }
    }
   //O(N) 
    public void imprimirInv(){
            System.out.println("");
        Nodo temp = fin;
         while(temp != null){
            System.out.print("[" + temp.getValor() + "]");
            temp = temp.getPrevio();
        }       
    
    }
        
   public int longitud(){
        return tam;
    }
   
       public boolean listaVacia(){
        if(inicio == null){ //LISTA VACÍA = VERDADERO
            return true;
        }else{//LISTA CON NODOS
            return false;
        }
    }
       
    public void vaciarLista(){
        inicio = null;
        fin = null;
        tam = 0;
    }
    
  public void agregar(int valor){
        Nodo nuevo = new Nodo(valor); //creo el nodo para el valor a insertar
        if(inicio == null){ //Lista vacía? verdadero
            inicio = nuevo; //nuevo es el primer nodo de la lista
            fin = nuevo;
        }else{ //lista con nodos
            fin.setSiguiente(nuevo);
            //conectar previo
            nuevo.setPrevio(fin);
            fin = nuevo;           
        }
        tam++; 
     }
  //O(N)
  public void InsertarEn(int valor, int posi){
    int tama = longitud();
    if(posi< 0 || posi >= tam){
        return;
    }
            if (posi == 0){
         Nodo nuevo = new Nodo(valor);
         if (listaVacia()){
             inicio = nuevo;
             fin = nuevo;
            } else {
             nuevo.setSiguiente(inicio);
             inicio.setPrevio(nuevo);
             inicio = nuevo;
            }
         tam++;
         return;
         }
            
            if (posi == tama){
                agregar(valor);
                return;
            }
        
        Nodo nuevo = new Nodo(valor);
        Nodo temp = inicio;
        
         for (int i = 0; i < posi-2; i++) {
            temp = temp.getSiguiente();
        }
        
         nuevo.setSiguiente(temp.getSiguiente());
         temp.setSiguiente(nuevo);
         nuevo.setPrevio(temp);
         nuevo.getSiguiente().setPrevio(nuevo);
         tam++;
    }
  
  //O(N)
  public void BorrarEn(int posi){
        
    int tama = longitud();
    if(posi< 0 || posi >= tam){
        return;
    }
    
    if(posi == 0){
        inicio = inicio.getSiguiente();
        if (inicio == null){
            fin = null;
            }
        tam--;
        return;
        }
    
    Nodo temp = inicio;
        for (int i = 0; i < posi - 2; i++) {
            temp = temp.getSiguiente();
        }
        Nodo borrar = temp.getSiguiente();
        temp.setSiguiente(borrar.getSiguiente());
        borrar.getSiguiente().setPrevio(temp);
        if(borrar==fin){
        fin = temp;
        }
        tam--;
    }
  
    public int valorEn(int posi){
        int tama = longitud();
        if (posi< 0 || posi >= tam){return 0;}else{
        int valor = 0;
        Nodo temp = inicio;  
        
        for (int i = 0; i < posi; i++) {
            temp = temp.getSiguiente();
        }
        return temp.getValor();  
        }
    }
    
    //QUEUE --> FIFO (PRIMERO EN LLEGAR PRIMERO EN SALIR)
  
    //AGREGA UN VALOR AL FINAL DE LA LISTA
    public void push(int valor){
    agregar(valor);    
    }
    
    //LEE EL VALOR DIRECTAMENTE ACCESIBLE, SIN BORRARLO
    public int peek(){
        return valorEn(0);
    }
    
    //LEE EL VALOR DIRECTAMENTE ACCESIBLE, Y DESPUÉS LO BORRA
    public void pop(){
        System.out.println(valorEn(0));
        BorrarEn(0);
    }
    
}

