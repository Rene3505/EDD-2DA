
package eva2_4_queue;


public class EVA2_4_QUEUE {


    public static void main(String[] args) {
        
    }
    
}
